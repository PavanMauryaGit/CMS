package com.cms.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entites.Customer;
import com.cms.repository.CustomerRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	@Transactional
	public Customer createCustomer(@Valid Customer customer) {
		
		return customerRepository.save(customer);
	}

	@Override
	public Optional<Customer> getCustomerById(Long id) {
		
		return customerRepository.findById(id);
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerRepository.findAll();
	}

	@Override
	public Customer updateCustomer(Long id,@Valid Customer customer) {
	    return customerRepository.findById(id)
	        .map(existingCustomer -> {
	            customer.setId(id);
	            return customerRepository.save(customer);
	        })
	        .orElseThrow(() -> new EntityNotFoundException("Customer with ID " + id + " not found"));
	}

	@Override
	public void deleteCustomer(Long id) {
		if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);
        }
	}

}
