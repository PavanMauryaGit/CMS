package com.cms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomermanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomermanagementsystemApplication.class, args);
	}

}
