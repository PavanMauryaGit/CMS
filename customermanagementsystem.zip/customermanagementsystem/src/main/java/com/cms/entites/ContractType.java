package com.cms.entites;

public enum ContractType {
    FULLTIME,
    PARTTIME
}

