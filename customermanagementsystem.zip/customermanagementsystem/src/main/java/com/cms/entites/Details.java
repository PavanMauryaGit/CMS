package com.cms.entites;


import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;



import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Embeddable
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Details {

    @Pattern(regexp = "M|F", message = "Sex should be 'M' or 'F'")
    private String sex;

    
    @Past(message = "DOB must be before 01-01-2002")
    private Date dob;

    private String nativeLocation;


}
